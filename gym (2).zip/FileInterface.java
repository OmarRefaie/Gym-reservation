package gym;

public interface FileInterface {

    public void read();

    public void write();

 
}
