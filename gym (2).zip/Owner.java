//package gym;
//
//import java.io.BufferedWriter;
//import java.io.FileNotFoundException;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.ArrayList;
//
//public class Owner extends Person implements FileInterface {
//
//    private ArrayList<Coach> coach = new ArrayList<>();
//    private ArrayList<MemberShip> memberShip = new ArrayList<>();
//    private ArrayList<Supplies> supplies = new ArrayList<>();
//
//    public Owner() {
//        super();
//    }
//
//    public Owner(String name, int id, long mobile, String email, String userName, String password, int weight, int height) {
//        super(name, id, mobile, email, userName, password, weight, height);
//    }
//
//    public void addMemberShip(MemberShip mem) {
//        memberShip.add(mem);
//    }
//
//    public void removeMemberShip(int i) {
//        memberShip.remove(i);
//        if(i==0)
//       memberShip.remove(i);
//
//    }
//
//    public void addCoach(Coach ob) {
//        coach.add(ob);
//    }
//
//    public void removeCoach(int i) {
//        coach.remove(i);
//        if(i==0)
//        coach.remove(i);
//
//    }
//
//    public void viewMemberShipList() {
//        for (int x = 0; x < memberShip.size(); x++) {
//            System.out.println(memberShip.get(x).getType() + " in " + memberShip.get(x).getPeriod() + " months :: " + memberShip.get(x).getPrice() + " LE");
//        }
//    }
//
//    public void viewSuppliesList() {
//        for (int x = 0; x < supplies.size(); x++) {
//            System.out.println("press " + (x + 1) + "for " + supplies.get(x).getProductName() + " :: " + supplies.get(x).getProuctPrice());
//        }
//    }
//
//    public void ViewCoachList() {
//        for (int x = 0; x < coach.size(); x++) {
//            System.out.println("press " + (x + 1) + " for coach " + coach.get(x).getName());
//        }
//    }
//
//    public String toString() {
//        return "..........Welcome to the GYM..........";
//    }
//
//    @Override
//    public void read() {
//    }
//
//    @Override
//    public void write() {
//        try {
//            FileWriter fw = new FileWriter("MemberShip plans.txt", true);
//            BufferedWriter bw = new BufferedWriter(fw);
//            PrintWriter print = new PrintWriter(bw);
//            for (int x = 0; x < memberShip.size(); x++) {
//                print.println(memberShip.get(x).getType() + " " + memberShip.get(x).getPeriod() + " " + memberShip.get(x).getPrice());
//            }
//            fw.close();
//            bw.close();
//            print.close();
//        } catch (FileNotFoundException ex) {
//        } catch (IOException ex) {
//        }
//    }
//
//   
//
//}
