//package gym;
//
//import java.util.ArrayList;
//
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.Scanner;
//import java.io.File;
//
//public class Client extends Person {
//
//    private double Clientmoney;
//    private MemberShip ob = new MemberShip();
//
//    public void setClientMoney(double money) {
//        Clientmoney = money;
//    }
//
//    public double getClientMoney() {
//        return Clientmoney;
//    }
//
//    public Client() {
//        super();
//        Clientmoney = 1000;
//    }
//
//    public Client(String name, int id, long mobile, String email, String userName, String password, int weight, int height) {
//        super(name, id, mobile, email, userName, password, weight, height);
//    }
//
//}
