//package gym;
//
//public class Person {
//
//    private String name;
//    private int id;
//    private long mobile;
//    private String email;
//    private String userName;
//    private String password;
//    private int weight;
//    private int height;
//
//    public Person() {
//        name = "enter name";
//        id = 0;
//        mobile = 0;
//        email = "enter your email";
//        userName = "enter your userName";
//        password = "enter your password";
//    }
//
//    public Person(String name, int id, long mobile, String email, String userName, String password, int weight, int height) {
//        this.name = name;
//        this.id = id;
//        this.mobile = mobile;
//        this.email = email;
//        this.userName = userName;
//        this.password = password;
//        this.weight = weight;
//        this.height = height;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setID(int id) {
//        this.id = id;
//    }
//
//    public int getID() {
//        return id;
//    }
//
//    public void setMobie(long mobile) {
//        this.mobile = mobile;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public long getMobile() {
//        return mobile;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    }
//
//    public String getUserName() {
//        return userName;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setWeight(int weight) {
//        this.weight = weight;
//    }
//
//    public int getWeight() {
//        return weight;
//    }
//
//    public void setHeight(int height) {
//        this.height = height;
//    }
//
//    public int getHeight() {
//        return height;
//    }
//
//}
