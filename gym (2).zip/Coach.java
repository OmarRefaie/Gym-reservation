//package gym;
//
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.Scanner;
//
//public class Coach extends Person implements FileInterface {
//
//    public Coach() {
//        super();
//    }
//
//    public Coach(String name, int id, long mobile, String email, String userName, String password, int weight, int height) {
//        super(name, id, mobile, email, userName, password, weight, height);
//    }
//
//   
//    @Override
//    public void read() {
//        try {
//            File file = new File("Coach.txt");
//            Scanner read = new Scanner(file);
//            String line;
//            int x = 0;
//            if (file.length() == 0) {
//                System.out.print("file is empty");
//                return;
//            }
//            while (read.hasNext()) {
//                line = read.nextLine();
//                System.out.println((x + 1) + ") " + line);
//                x++;
//            }
//            read.close();
//        } catch (FileNotFoundException ex) {
//        }
//    }
//
//    @Override
//    public void write() {
//
//        FileWriter fw = null;
//        try {
//            fw = new FileWriter("Coach.txt", true);
//            BufferedWriter bw = new BufferedWriter(fw);
//            PrintWriter write = new PrintWriter(bw);
//            write.println(getName() + " " + getID());
//            write.close();
//            fw.close();
//            bw.close();
//        } catch (IOException ex) {
//        }
//
//    }
//
//
//
//}
