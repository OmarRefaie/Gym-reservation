/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gym;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Shop extends JFrame
{

    
  private  ArrayList<JCheckBox> box = new ArrayList<JCheckBox>();
    public Shop() throws IOException
    {
//         JLabel label= new JLabel("Welcome to the Gym's shop :) ");
        setLayout(new BorderLayout());
        JPanel p=new JPanel();
        JPanel p1=new JPanel();
        p1.add(new JButton("purchase"));
//        label.setFont(new Font("Courier", Font.BOLD, 20));
               p. setLayout(new GridLayout(0,box.size()+1,10,10));

//        p.add(label);
        box.add(new JCheckBox("water"));
        box.add(new JCheckBox("Dark chocolate"));
        box.add(new JCheckBox("weight protine"));
        box.add(new JCheckBox("dumbbell"));
        
//         getContentPane().setBackground(Color.WHITE);
        for(int x=0;x<box.size();x++)
        {
            p.add(box.get(x));
        }
       add(p,"Center");
       add(p1,"East");
    setSize(900,500);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    setLocationRelativeTo(null);
    setVisible(true);
    }    

  
}
