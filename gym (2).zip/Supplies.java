package gym;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


public class Supplies implements FileInterface {

    private String productName;
    private double productPrice;

    public Supplies() {
        this.productName = "enter product name";
        this.productPrice = 0;
    }

    public Supplies(String productName, double Price) {
        this.productName = productName;
        this.productPrice = Price;
    }

    public double getProuctPrice() {
        return productPrice;
    }

    public String getProductName() {
        return productName;
    }

    public void SetProductName(String name) {
        this.productName = name;
    }

    public void setProductPrice(double price) {
        productPrice = price;
    }

    @Override
    public void read() {
        String line;
        int x = 0;
        File file = new File("Supplis.txt");
        try {
            if (file.length() == 0) {
                System.out.print("file is empty");
                return;
            }
            Scanner read = new Scanner(file);
            while (read.hasNext()) {
                line = read.nextLine();
                System.out.println("press " + (x + 1) + " " + line);
                x++;
            }
            read.close();
        } catch (FileNotFoundException ex) {
        }

    }

    @Override
    public void write() {
        try {
            FileWriter fw = new FileWriter("Supplis.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter write = new PrintWriter(bw);
            write.println(getProductName() + " " + getProuctPrice() + "LE ");
            write.close();
            fw.close();
            bw.close();
        } catch (FileNotFoundException ex) {
        } catch (IOException ex) {
        }
    }



}
