//package gym;
//
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.io.PrintWriter;
//import java.util.Scanner;
//
//public class MemberShip implements FileInterface {
//
//    private String type;
//    private int period;
//    private double price;
//
//    public MemberShip() {
//        type = "enter type";
//        period = 0;
//        price = 0;
//    }
//
//    public MemberShip(String type, int p, double price) {
//        this.type = type;
//        period = p;
//        this.price = price;
//    }
//
//    public void setTypememberShip(String Type) {
//        this.type = Type;
//    }
//
//    public String getType() {
//        return type;
//    }
//
//    public void SetPeriod(int period) {
//        this.period = period;
//    }
//
//    public int getPeriod() {
//        return period;
//    }
//
//    public void setPrice(double price) {
//        this.price = price;
//    }
//
//    public double getPrice() {
//        return price;
//    }
//
//    @Override
//    public void read() {
//        try {
//            File myfile = new File("memberShip.txt");
//            Scanner read = new Scanner(myfile);
//            String line;
//            int x = 0;
//            if (myfile.length() == 0) {
//                System.out.print("file is empty");
//                return;
//            }
//            while (read.hasNext()) {
//                line = read.nextLine();
//                System.out.println((x + 1) + ") " + line);
//                x++;
//            }
//            read.close();
//        } catch (FileNotFoundException ex) {
//        }
//    }
//
//    @Override
//    public void write() {
//        try {
//            FileWriter fw = new FileWriter("memberShip.txt", true);
//            BufferedWriter bw = new BufferedWriter(fw);
//            PrintWriter write = new PrintWriter(bw);
//            write.println(getType() + " " + getPeriod() + "months " + getPrice() + "LE");
//            write.close();
//            fw.close();
//            bw.close();
//        } catch (FileNotFoundException ex) {
//        } catch (IOException ex) {
//        }
//
//    }
//
//
//
//}
